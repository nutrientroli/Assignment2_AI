Hem detectat que en funci� d'on desis el projecte, Unity presenta errors al obrir-lo.
Sembla ser un tema de nom d'url massa llarg.

Ho comentem per si et succeeix, que s�pigues que no �s un tema del projecte en s�!

